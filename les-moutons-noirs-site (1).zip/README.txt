
Les Moutons Noirs - Website
---------------------------

Files included:
- index.html
- logo.jpg (if provided)
- pexels-alessio-cesario-975080-1906795.jpg (if provided)
- pexels-cottonbro-5089178.jpg (if provided)

How to preview locally:
1. Download the folder and open index.html in a browser.
2. Or run a simple local server (recommended):
   - Python 3: `python -m http.server` then open http://localhost:8000

How to host for free:
- GitHub Pages:
  1. Create a new GitHub repository.
  2. Add the files and push.
  3. In repo Settings -> Pages, set source to 'main' branch and root folder.
  4. Your site will be available at https://<username>.github.io/<repo>/

- Netlify (simple drag & drop):
  1. Zip the folder.
  2. Sign in to Netlify, drag the zip into Sites > Add new site > Import from ZIP.
  3. Netlify will publish with HTTPS automatically.

Notes:
- For the embossed logo to look best, use a PNG with a transparent background named 'logo.png' and replace logo.jpg.
- To use server-handled forms, consider Netlify Forms or Formspree; currently the form uses mailto to open the user's email client.
